!define VERSION "2.11.09rc2"
!define MAJOR_VER 11
!define MINOR_VER 11
!define SUBMINOR_VER 8
!define PATCHLEVEL_VER 92
