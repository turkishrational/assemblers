/*
 * This file is generated from insns.dat, regs.dat and token.dat
 * by tokhash.pl; do not edit.
 */

#ifndef NASM_TOKENS_H
#define NASM_TOKENS_H

#define MAX_KEYWORD 13 /* length of longest keyword */

#endif /* NASM_TOKENS_H */
