To ensure successful compilation with LLVM (clang) and TDM (tcc),
I removed the "macho32" and "macho64" obj/output format code 
from the "Makefile" and "outform.h" files.

Erdogan Tan - 16/04/2026