tcc -o ndisasm.exe ^
ndisasm.c disasm.c sync.c nasmlib.c ver.c insnsd.c insnsb.c ^
insnsn.c regs.c regdis.c disp8.c iflag.c ilog2.c
