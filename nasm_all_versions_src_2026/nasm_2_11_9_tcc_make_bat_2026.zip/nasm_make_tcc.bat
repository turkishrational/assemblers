tcc -o nasm.exe ^
nasm.c nasmlib.c ver.c raa.c saa.c rbtree.c float.c insnsa.c insnsb.c ^
directiv.c assemble.c labels.c hashtbl.c crc64.c parser.c ^
outform.c outlib.c nulldbg.c nullout.c outbin.c ^
outaout.c outcoff.c outelf.c outelf32.c outelf64.c outelfx32.c ^
outobj.c outas86.c outrdf2.c outdbg.c outieee.c ^
preproc.c quote.c pptok.c macros.c listing.c eval.c exprlib.c stdscan.c ^
strfunc.c tokhash.c regvals.c regflags.c ilog2.c strlcpy.c preproc-nop.c ^
disp8.c iflag.c outmac32.c outmac64.c

