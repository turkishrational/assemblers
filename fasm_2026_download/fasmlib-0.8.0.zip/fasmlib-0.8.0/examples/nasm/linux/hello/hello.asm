;FASMLIB Hello World example in NASM/YASM for linux
;uses ELF version of FASMLIB

;compile with:
;  nasm -f elf hello.asm
;link with: (in bash)
;  ld -e start hello.o $FASMLIB/bin/fasmlib.o -o hello

%include "%!FASMLIB/include/nasm/fasmlib.inc"
global start
[section .text]
start:
	;initialize FASMLIB
	call	fasmlib.init
	jc	error

	;display string
	push	_hello
	call	stdout.write
	jc	error

	;uninitialize FASMLIB
	call	fasmlib.uninit
	jc	error

	;exit with code 0
	push	0
	call	process.exit

;error handler
error:
	;get error message
	push	eax
	call	err.text

	;display error message
	push	eax
	push	_err_format
	call	stderr.write.format

	;uninitialize FASMLIB
	call	fasmlib.shutdown

	;exit with code 1
	push	1
	call	process.exit

[section .data]
_hello		db "Hell o' World",10,0
_err_format	db 10,"Error: %s",10,0
