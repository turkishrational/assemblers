;FASMLIB Hello World portable example in NASM/YASM
;With FASMLIB and NASM/YASM, you can use exactly same source for both win32 and linux

;win32:
;compile with:
;  nasm -f win32 hello.asm
;link with: (with MS link and MS Visual C/C++ libcmt.lib)
;  link /subsystem:console /entry:start hello.obj libcmt.lib "%FASMLIB%\bin\fasmlib.lib" kernel32.lib

;linux:
;compile with:
;  nasm -f elf hello.asm
;link with: (in bash)
;  ld -e _start hello.o $FASMLIB/bin/elf_linux.o -o hello


%include "%!FASMLIB/include/nasm/fasmlib.inc"
global _start
[section .text]
_start:
	;initialize FASMLIB
	call	fasmlib.init
	jc	error

	;display string
	push	_hello
	call	stdout.write
	jc	error

	;uninitialize FASMLIB
	call	fasmlib.uninit
	jc	error

	;exit with code 0
	push	0
	call	process.exit

;error handler
error:
	;get error message
	push	eax
	call	err.text

	;display error message
	push	eax
	push	_err_format
	call	stderr.write.format

	;uninitialize FASMLIB
	call	fasmlib.shutdown

	;exit with code 1
	push	1
	call	process.exit

[section .data]
_hello		db "Hell o' World",10,0
_err_format	db 10,"Error: %s",10,0
