;dec2hex example of FASMLIB usage in NASM/YASM

;compile with:
;  nasm -f win32 dec2hex.asm
;link with: (using MS link)
;  link /entry:start /subsystem:console dec2hex.obj "%FASMLIB%/bin/fasmlib.lib"

%include "%!FASMLIB/include/nasm/fasmlib.inc"
global _start
[section .text]
_start: 
	;initialize FASMLIB
	call	fasmlib.init
	jc	error

	;write prompt
	push	_example
	call	stdout.write
	jc	error

	;EBX = read decimal number
	call	stdin.read.dec_d
	jc	error
	mov	ebx, eax

	;write notice
	push	_hex
	call	stdout.write
	jc	error

	;write EBX as hex number
	push	ebx
	call	stdout.write.d_hex
	jc	error

	;uninitialize FASMLIB
	call	fasmlib.uninit
	jc	error

	;exit with code 0
	push	0
	call	process.exit

;error handler
error:
	;get error message
	push	eax
	call	err.text

	;display error message
	push	eax
	push	_err_format
	call	stderr.write.format

	;uninitialize FASMLIB
	call	fasmlib.shutdown

	;exit with code 1
	push	1
	call	process.exit

[section .data]
_example	db "Example of FASMLIB usage in NASM and YASM", 10
		db "Please type decimal dword value: ",0
_hex		db "It's 0x",0
_err_format	db 10,"Error: %s",10,0
