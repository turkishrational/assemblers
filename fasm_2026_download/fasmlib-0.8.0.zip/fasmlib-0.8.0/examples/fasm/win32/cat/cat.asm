;"cat" example of FASMLIB usage from FASM
;uses "fileio" to read file
;includes FASMLIB directly by source

;compile with:
;  fasm dec2hex.asm

BUFFER_SIZE = 100

format PE

SYSTEM equ win32
include "%fasminc%/win32ax.inc"
include "%fasmlib%/include/fasm/fasmlib-src.inc"

.code

start:
	;initialize FASMLIB
	libcall fasmlib.init
	jc	error

	;EBX = open file
	push	0		;read-only
	push	_filename
	call	fileio.open
	jc	error
	mov	ebx, eax

read_block:
	;read data to buffer
	push	BUFFER_SIZE
	push	buffer
	push	ebx
	call	fileio.read
	jc	error2

	;if OF is returned, we reached EOF before reading BUFFER_SIZE bytes
	seto	dl

	;write readen data to stdout
	push	eax		;EAX holds number of bytes readen by fileio.read
	push	buffer
	push	stdout
	call	stream.write
	jc	error2

	;continue loop, unless this was last part
	test	dl, dl
	jz	read_block
done:

	;close file
	push	ebx
	call	fileio.close
	jc	error

	;uninitialize FASMLIB
	call	fasmlib.uninit
	jc	error

	;end program with exit code 0
	push	0
	call	process.exit


	;error happened, but before displaying it we should close file
error2:
	push	eax	;save error code

	push	ebx
	call	fileio.close

	pop	eax	;restore error code


	;display error and exit
error:
	;EAX = error message associated with error code in EAX
	push	eax
	call	err.text

	;write error message
	push	eax
	push	_err_format
	call	stderr.write.format

	;uninitialize FASMLIB
	call	fasmlib.shutdown

	;end program with exit code 1
	push	1
	call	process.exit

.data
	_filename	db "cat.asm", 0
	buffer		rb BUFFER_SIZE
	_err_format	db "ERROR: %s!",10,0

	IncludeIData
	IncludeUData

.end start