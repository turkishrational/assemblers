;dec2hex example of FASMLIB usage from FASM
;includes FASMLIB directly by source

;compile with:
;  fasm dec2hex.asm

format PE

include "%fasminc%/win32ax.inc"

.code

	;include FASMLIB
	SYSTEM equ win32
	include "%fasmlib%/include/fasm/fasmlib-src.inc"


start:
	;initialize FASMLIB
	call	fasmlib.init
	jc	error

	;write prompt
	push	_example
	call	stdout.write
	jc	error

	;read decimal number
	call	stdin.read.dec_d
	jc	error

	;write it as hex number
	push	eax
	push	_hex_format
	call	stdout.write.format
	jc	error

	;uninitialize FASMLIB
	call	fasmlib.uninit
	jc	error

	;end program with exit code 0
	push	0
	call	process.exit



	;on error, EAX contains error code
error:
	;EAX = error message associated with error code in EAX
	push	eax
	call	err.text

	;write error message
	push	eax
	push	_err_format
	call	stderr.write.format

	;uninitialize FASMLIB
	call	fasmlib.shutdown

	;end program with exit code 1
	push	1
	call	process.exit

.data
	_example	db "Example of FASMLIB usage in FASM ", 10
			db "Please type decimal dword value: ",0

	_hex_format	db "It's 0x%h",0

	_err_format	db 10, "Error: %s!",10,0

	IncludeIData
	IncludeUData

.end start