;example of using PE exports for symbolic information

format PE
entry start

;code
section '.code' code executable readable

;include FASMLIB
SYSTEM equ win32
include "%fasmlib%/include/fasm/fasmlib-src.inc"

start:
	;initialize FASMLIB
	call	fasmlib.init
	jc	error

	;write prompt
	push	_hello
	call	stdout.write
	jc	error

	;uninitialize FASMLIB
	call	fasmlib.uninit
	jc	error

	;end program with exit code 0
	push	0
	call	process.exit



	;on error, EAX contains error code
error:
	;EAX = error message associated with error code in EAX
	push	eax
	call	err.text

	;write error message
	push	eax
	push	_err_format
	call	stderr.write.format

	;uninitialize FASMLIB
	call	fasmlib.shutdown

	;end program with exit code 1
	push	1
	call	process.exit

;data
section '.data' data readable writeable

	_hello		db "1-13||0 \/\/oR1|)", 10
	_err_format	db 10, "Error: %s!",10,0

	IncludeIData
	IncludeUData

;imports
section '.import' data import readable
	;standard FASM macros for importing
	include "%FASMINC%/macro/import32.inc"

	;imports that FASMLIB needs
	library kernel32, "kernel32.dll"
	include "%FASMINC%/API/kernel32.inc"

;exports
section '.export' data export readable
	;FASMLIB macro to produce symbols
	include "%FASMLIB%/include/fasm/pe-symbols.inc"

	;list of symbols (FASMLIB symbols included automatically)
	symbols "SYMBOLS.EXE",\ 	;name of module
		start,	     'start',\
		error,	     'error',\
		_hello,      '_hello',\
		_err_format, '_err_format'