format ELF executable
entry start

;code
segment readable executable

	;include FASMLIB
	SYSTEM equ linux
	include '%FASMLIB%/include/fasm/fasmlib-src.inc'

	;include portable part of code
	include "main.inc"

;data
segment readable writeable

	IncludeIData
	IncludeUData
