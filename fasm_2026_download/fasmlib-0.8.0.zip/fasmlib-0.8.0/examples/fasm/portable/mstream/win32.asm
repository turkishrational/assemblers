;portable FASMLIB example of using memory streams
;uses nested "libcall"
;win32 version

format PE console

include '%FASMINC%/win32ax.inc'

.code

	;include FASMLIB
	SYSTEM EQU win32
	include '%FASMLIB%/include/fasm/fasmlib-src.inc'

	;include portable part of code
	include "main.inc"

.data
	IncludeIData
	IncludeUData

.end start
