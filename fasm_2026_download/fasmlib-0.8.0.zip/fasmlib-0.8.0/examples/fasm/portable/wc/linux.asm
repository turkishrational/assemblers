;portable FASMLIB example of word count using file streams
;also demonstrates usage of "libcall" macro
;linux version

DISPLAY_PROC_INFO equ 1

format ELF executable
entry start

;code
segment readable executable

	;include FASMLIB
	SYSTEM equ linux
	include '%FASMLIB%/include/fasm/fasmlib-src.inc'

	;include portable part of code
	include "main.inc"

;data
segment readable writeable

	IncludeIData
	IncludeUData
