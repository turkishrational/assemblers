;FASMLIB example of portable program that converts text to hex dump,
;also demonstrates usage of "libcall" macro
;linux version

format ELF executable
entry start

;code
segment readable executable

	;include FASMLIB
	SYSTEM equ linux
	include '%FASMLIB%/include/fasm/fasmlib-src.inc'

	;include portable part of code
	include "main.inc"

;data
segment readable writeable

	IncludeIData
	IncludeUData
