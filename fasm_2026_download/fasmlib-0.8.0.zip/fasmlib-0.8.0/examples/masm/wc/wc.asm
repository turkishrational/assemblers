; word count example of FASMLIB usage in MASM

; compile with:
;       ml /c /coff wc.asm
; link with:
;       link /subsystem:console /entry:start wc.obj "%FASMLIB%\bin\fasmlib.lib" kernel32.lib

.586
.model flat, stdcall
option casemap:none    ; case sensitive

;include FASMLIB headers
%include @Environ(FASMLIB)\\include\\masm\\fasmlib.inc

.data
	;prompts
	_prompt 	db "Please type name of file (max %d chars): ",0
	_result 	db "File %s contains %d words.",10,0

	;sample word delimiters
	_word_delims	db 9,10,13," .,:",0

	_err_format	db 10, "Error: %s!",10,0

	;file name buffer
	MAX_FILENAME=80+1
	filename	db MAX_FILENAME dup (?)

.code

start:
	;initialize FASMLIB
	invoke	fasmlib_init
	jc	error

	;write prompt
	push	MAX_FILENAME-1
	invoke	stdout_write_format, offset _prompt
	jc	error

	;read file name
	invoke	stdin_read_line, offset filename, MAX_FILENAME-1
	jc	error

	;EBX = open file as stream
	invoke	file_open, offset filename, 0
	jc	error
	mov	ebx, eax

	;ECX = number of words
	xor	ecx, ecx

next_word:

	;skip all delimiters
	invoke	text_skip_chars, ebx, offset _word_delims
	jc	error

	;if we were on end of file, end loop
	jo	done

	;skip word
	invoke	text_skip_until, ebx, offset _word_delims
	jc	error

	;if we were on end of file, end loop
	jo	done

	;another word done
	inc	ecx

	jmp	next_word

done:
	;print result
	push	ecx
	push	offset filename
	invoke	stdout_write_format, offset _result
	jc	error

	;close file
	invoke	file_close, ebx
	jc	error

	;uninitialize FASMLIB
	invoke	fasmlib_uninit
	jc	error

	;end program with exit code 0
	invoke	process_exit, 0



	;on error, EAX contains error code
error:
	;EAX = error message associated with error code in EAX
	invoke	err_text, eax

	;display error message
	push	eax
	invoke	stderr_write_format, offset _err_format

	;uninitialize FASMLIB
	invoke	fasmlib_shutdown

	;end program with exit code 1
	invoke	process_exit, 1

end start