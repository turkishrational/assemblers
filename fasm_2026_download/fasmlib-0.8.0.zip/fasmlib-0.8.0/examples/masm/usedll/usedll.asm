; example of using DLL version of FASMLIB

; compile with:
;       ml /c /coff usedll.asm
; link with:
;       link /subsystem:console usedll.obj "%FASMLIB%\bin\fasmlib-dll.lib


.586
.model flat, stdcall
option casemap:none    ; case sensitive

;include FASMLIB headers
%include @Environ(FASMLIB)\\include\\masm\\fasmlib.inc


.data
	_hello		db "Hell o' World",0

	_err_format	db 10, "Error: %s!",10,0



.code

start:
	;initialize FASMLIB
	invoke	fasmlib_init
	jc	error

	;write prompt
	invoke	stdout_write, offset _hello
	jc	error

	;uninitialize FASMLIB
	invoke	fasmlib_uninit
	jc	error

	;end program with exit code 0
	invoke	process_exit, 0



	;on error, EAX contains error code
error:
	;EAX = error message associated with error code in EAX
	invoke	err_text, eax

	;display error message
	push	eax
	invoke	stderr_write_format, offset _err_format

	;uninitialize FASMLIB
	invoke	fasmlib_shutdown

	;end program with exit code 1
	invoke	process_exit, 1

end start