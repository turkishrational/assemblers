; dec2hex example of FASMLIB usage in MASM

; compile with:
;       ml /c /coff dec2hex.asm
; link with:
;       link /subsystem:console wc.obj "%FASMLIB%\bin\fasmlib.lib" kernel32.lib


.586
.model flat, stdcall
option casemap:none    ; case sensitive

;include FASMLIB headers
%include @Environ(FASMLIB)\\include\\masm\\fasmlib.inc


.data
	_prompt 	db "Example of FASMLIB usage in MASM ", 10
			db "Please type decimal dword value: ",0

	_hex		db "It's 0x",0

	_err_format	db 10, "Error: %s!",10,0



.code

start:
	;initialize FASMLIB
	invoke	fasmlib_init
	jc	error

	;write prompt
	invoke	stdout_write, offset _prompt
	jc	error

	;EBX = read decimal number
	invoke	stdin_read_dec_d
	jc	error
	mov	ebx, eax

	;write notice
	invoke	stdout_write, offset _hex
	jc	error

	;write EBX as hex number
	invoke	stdout_write_d_hex, ebx
	jc	error

	;uninitialize FASMLIB
	invoke	fasmlib_uninit
	jc	error

	;end program with exit code 0
	invoke	process_exit, 0



	;on error, EAX contains error code
error:
	;EAX = error message associated with error code in EAX
	invoke	err_text, eax

	;display error message
	push	eax
	invoke	stderr_write_format, offset _err_format

	;uninitialize FASMLIB
	invoke	fasmlib_shutdown

	;end program with exit code 1
	invoke	process_exit, 1

end start