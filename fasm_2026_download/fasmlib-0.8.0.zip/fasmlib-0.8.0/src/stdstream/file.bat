if "%3"=="" goto twoargs
  sed -e s/XXX/%1.%2/g;s/STREAM/%STREAM%/g; xxx.inc >%STREAM%\%1_%2.inc 
  goto done
goto done

:twoargs
if "%2"=="" goto empty
  sed -e s/XXX/%1.%2/g;s/STREAM/%STREAM%/g; xxx.inc >%STREAM%\%1_%2.inc 
  goto done
:empty
  sed -e s/XXX/%1/g;s/STREAM/%STREAM%/g; xxx.inc >%STREAM%\%1.inc 
:done

