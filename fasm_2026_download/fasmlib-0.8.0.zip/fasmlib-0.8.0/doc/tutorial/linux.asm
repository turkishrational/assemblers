; stub to compile "main.inc" for linux
; (you must have environment variable FASMLIB set,
; see manual -> Usage -> Environment varaible FASMLIB)

format ELF executable
entry start

segment readable executable

SYSTEM equ linux
include '%FASMLIB%/include/fasm/fasmlib-src.inc'

start:
	include "main.inc"

segment readable writeable

	IncludeIData
	IncludeUData
