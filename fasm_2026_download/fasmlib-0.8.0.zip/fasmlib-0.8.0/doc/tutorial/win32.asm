; stub to compile "main.inc" for win32
; (you must have environment variable FASMLIB set,
; see manual -> Usage -> Environment varaible FASMLIB)

format PE console
include '%FASMINC%/win32ax.inc'

.code

SYSTEM EQU win32
include '%FASMLIB%/include/fasm/fasmlib-src.inc'

start:
	include "main.inc"

.data
IncludeIData
IncludeUData

.end start